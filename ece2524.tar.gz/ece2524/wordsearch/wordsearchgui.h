#ifndef WORDSEARCHGUI_H
#define WORDSEARCHGUI_H

#include <QMainWindow>
#include <QFile>
#include <QStandardItemModel>

namespace Ui {
class wordsearchgui;
}

class wordsearchgui : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit wordsearchgui(QWidget *parent = 0);
    void addList();
    ~wordsearchgui();

public slots:
    void addWordPress();
    void generatePress();
    void onCellClick(int, int);
    void onEnterPress();
    
private:
    Ui::wordsearchgui *ui;
    QList<QString> wordList;
    bool generatable;
    int toggle;
    int checkFile();
    void addWordtoFile(QString);
    void updateList(/*Filename*/);
};

#endif // WORDSEARCHGUI_H
