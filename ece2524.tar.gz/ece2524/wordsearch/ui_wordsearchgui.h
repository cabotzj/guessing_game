/********************************************************************************
** Form generated from reading UI file 'wordsearchgui.ui'
**
** Created: Tue May 1 18:34:15 2012
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WORDSEARCHGUI_H
#define UI_WORDSEARCHGUI_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QMainWindow>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QTableWidget>
#include <QtGui/QTextEdit>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_wordsearchgui
{
public:
    QWidget *centralWidget;
    QPushButton *enterButton;
    QWidget *gridLayoutWidget_2;
    QGridLayout *gridLayout_2;
    QSpinBox *row1spin;
    QSpinBox *row2spin;
    QSpinBox *col1spin;
    QSpinBox *col2spin;
    QPushButton *generateButton;
    QTableWidget *wordSearchDisplay;
    QLineEdit *foundLine;
    QLineEdit *unfoundLine;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLineEdit *addWordEdit;
    QPushButton *addWordButton;
    QTextEdit *unfoundList;
    QTextEdit *foundList;

    void setupUi(QMainWindow *wordsearchgui)
    {
        if (wordsearchgui->objectName().isEmpty())
            wordsearchgui->setObjectName(QString::fromUtf8("wordsearchgui"));
        wordsearchgui->resize(600, 449);
        wordsearchgui->setMinimumSize(QSize(400, 0));
        centralWidget = new QWidget(wordsearchgui);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        enterButton = new QPushButton(centralWidget);
        enterButton->setObjectName(QString::fromUtf8("enterButton"));
        enterButton->setGeometry(QRect(190, 400, 145, 27));
        gridLayoutWidget_2 = new QWidget(centralWidget);
        gridLayoutWidget_2->setObjectName(QString::fromUtf8("gridLayoutWidget_2"));
        gridLayoutWidget_2->setGeometry(QRect(50, 380, 126, 62));
        gridLayout_2 = new QGridLayout(gridLayoutWidget_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        row1spin = new QSpinBox(gridLayoutWidget_2);
        row1spin->setObjectName(QString::fromUtf8("row1spin"));

        gridLayout_2->addWidget(row1spin, 0, 0, 1, 1);

        row2spin = new QSpinBox(gridLayoutWidget_2);
        row2spin->setObjectName(QString::fromUtf8("row2spin"));

        gridLayout_2->addWidget(row2spin, 2, 0, 1, 1);

        col1spin = new QSpinBox(gridLayoutWidget_2);
        col1spin->setObjectName(QString::fromUtf8("col1spin"));

        gridLayout_2->addWidget(col1spin, 0, 1, 1, 1);

        col2spin = new QSpinBox(gridLayoutWidget_2);
        col2spin->setObjectName(QString::fromUtf8("col2spin"));

        gridLayout_2->addWidget(col2spin, 2, 1, 1, 1);

        generateButton = new QPushButton(centralWidget);
        generateButton->setObjectName(QString::fromUtf8("generateButton"));
        generateButton->setGeometry(QRect(100, 340, 121, 27));
        wordSearchDisplay = new QTableWidget(centralWidget);
        wordSearchDisplay->setObjectName(QString::fromUtf8("wordSearchDisplay"));
        wordSearchDisplay->setGeometry(QRect(10, 10, 321, 321));
        foundLine = new QLineEdit(centralWidget);
        foundLine->setObjectName(QString::fromUtf8("foundLine"));
        foundLine->setGeometry(QRect(340, 10, 121, 27));
        unfoundLine = new QLineEdit(centralWidget);
        unfoundLine->setObjectName(QString::fromUtf8("unfoundLine"));
        unfoundLine->setGeometry(QRect(470, 10, 121, 27));
        horizontalLayoutWidget = new QWidget(centralWidget);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(340, 340, 251, 31));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        addWordEdit = new QLineEdit(horizontalLayoutWidget);
        addWordEdit->setObjectName(QString::fromUtf8("addWordEdit"));

        horizontalLayout->addWidget(addWordEdit);

        addWordButton = new QPushButton(horizontalLayoutWidget);
        addWordButton->setObjectName(QString::fromUtf8("addWordButton"));
        addWordButton->setMinimumSize(QSize(87, 0));

        horizontalLayout->addWidget(addWordButton);

        unfoundList = new QTextEdit(centralWidget);
        unfoundList->setObjectName(QString::fromUtf8("unfoundList"));
        unfoundList->setGeometry(QRect(470, 40, 121, 291));
        foundList = new QTextEdit(centralWidget);
        foundList->setObjectName(QString::fromUtf8("foundList"));
        foundList->setGeometry(QRect(340, 40, 121, 291));
        wordsearchgui->setCentralWidget(centralWidget);

        retranslateUi(wordsearchgui);

        QMetaObject::connectSlotsByName(wordsearchgui);
    } // setupUi

    void retranslateUi(QMainWindow *wordsearchgui)
    {
        wordsearchgui->setWindowTitle(QApplication::translate("wordsearchgui", "wordsearchgui", 0, QApplication::UnicodeUTF8));
        enterButton->setText(QApplication::translate("wordsearchgui", "Enter Coordinates", 0, QApplication::UnicodeUTF8));
        generateButton->setText(QApplication::translate("wordsearchgui", "Generate Map", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        wordSearchDisplay->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        foundLine->setText(QApplication::translate("wordsearchgui", "Found Words", 0, QApplication::UnicodeUTF8));
        unfoundLine->setText(QApplication::translate("wordsearchgui", "Unfound Words", 0, QApplication::UnicodeUTF8));
        addWordButton->setText(QApplication::translate("wordsearchgui", "Add Word", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class wordsearchgui: public Ui_wordsearchgui {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WORDSEARCHGUI_H
