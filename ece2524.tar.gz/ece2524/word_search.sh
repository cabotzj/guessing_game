#!/bin/bash

echo "*************************************************"
echo "----------Welcome to Word Search 1000!-----------"
echo "*************************************************"

echo ""
echo ""

echo "To play game, enter in coordinates for the first and last"
echo "letter of the word starting from top left corner as 11 while"
echo "the bottom corner would be 1010!"

echo ""
echo ""

if [ "$1" == "start" ]; then
echo "Starting Puzzle $2!"
echo " "
echo " "

echo "Unfound Words: "
	if [ "$2" == "1" ]; then
	while read line; do
		echo "${line}"
	done < randomlist.dat
	
	echo " "

	while read line; do
		echo "${line}"
	done < random.dat

	elif [ "$2" == "2" ]; then

	while read line; do
		echo "${line}"
	done < animalslist.dat

	echo " "	

	while read line; do
		echo "${line}"
	done < animals.dat

	fi

rm unfoundtemp.dat
rm foundtemp.dat

while read line; do
	echo "${line}" >> unfoundtemp.dat
done < randomlist.dat

echo > foundtemp.dat


elif [ "$1" == "help" ];then
echo "The correct format for the command is: "
echo "word_search <start/gui/words/found/help> <1/2> <location>"
fi

if [ "$1" == "words" ]; then
	while read line; do
	echo "${line}"
	done < randomlist.dat
fi

if [ "$1" == "gui" ]; then
	./wordsearch/wordsearch
fi



