#include "wordsearchgui.h"
#include "ui_wordsearchgui.h"

wordsearchgui::wordsearchgui(QWidget *parent) :QMainWindow(parent), ui(new Ui::wordsearchgui)
{
    ui->setupUi(this);
    ui->unfoundList->setReadOnly(true);
    ui->foundList->setReadOnly(true);
    ui->unfoundLine->setReadOnly(true);
    ui->foundLine->setReadOnly(true);

    ui->wordSearchDisplay->setColumnCount(10);
    ui->wordSearchDisplay->setRowCount(10);
    for(int i = 0; i<10; i++){
    ui->wordSearchDisplay->setColumnWidth(i,ui->wordSearchDisplay->width()/10.8);
    ui->wordSearchDisplay->setRowHeight(i, ui->wordSearchDisplay->height()/10.8);
    }

    //connect(ui->addWordButton, SIGNAL(clicked()), this, SLOT(addWordPress()));
    //connect(ui->generateButton, SIGNAL(clicked()), this, SLOT(generatePress()));
    connect(ui->enterButton, SIGNAL(clicked()), this, SLOT(onEnterPress()));
    connect(ui->wordSearchDisplay, SIGNAL(cellClicked(int,int)), this, SLOT(onCellClick(int,int)));

    generatable = true;
    toggle = 0;
    gamenumber = 0;
    updateList();
    checkGame();
    if(gamenumber != 0) generatePress();
}

void wordsearchgui::updateList(){
        ui->unfoundList->clear();
        wordList.clear();


        QFile tempfile("./unfoundtemp.dat");

         if (!tempfile.open(QIODevice::ReadOnly | QIODevice::Text)){
             ui->unfoundList->insertHtml("unfoundtemp problem <br>");
               return;
         }

           while (!tempfile.atEnd()) {
               QByteArray line = tempfile.readLine();
               wordList.append(line);
           }
           addList();
}

void wordsearchgui::updateFoundList(){


}

void wordsearchgui::addList(){
    ui->unfoundList->clear();

    QList<QString>::iterator i;
     for (i = wordList.begin(); i != wordList.end(); ++i)
         ui->unfoundList->insertHtml(*i + "<br>");
}

/*void wordsearchgui::addWordPress(){
    QString temp = ui->addWordEdit->text().trimmed();
    temp.truncate(7);
    bool toggle = true;


    QList<QString>::iterator i;
     for (i = wordList.begin(); i != wordList.end(); ++i){
         if(temp == *i) toggle = false;
         if(wordList.size() == 10) toggle = false;
     }


    if(toggle == true) ui->unfoundList->insertHtml(temp + "<br>");
    if(toggle == true) wordList.append(temp);
    if(toggle == true) addWordtoFile(temp);
    ui->addWordEdit->clear();

    generatable = true;
}*/

void wordsearchgui::onCellClick(int row, int column){
    if(toggle == 0){
        ui->row1spin->clear();
        ui->col1spin->clear();
        ui->row2spin->clear();
        ui->col2spin->clear();
        ui->row1spin->setValue(row+1);
        ui->col1spin->setValue(column+1);
        toggle = 1;
    }
    else {
        ui->row2spin->setValue(row+1);
        ui->col2spin->setValue(column+1);
        toggle = 0;
    }

}

void wordsearchgui::checkGame(){

    QList<QString> animalsList;
    QList<QString> randomList;

    QFile file1("./animalslist.dat");
    QFile file2("./randomlist.dat");

     if (!file1.open(QIODevice::ReadOnly | QIODevice::Text)){
         ui->unfoundList->insertHtml("animals problem <br>");
           return;
     }

       while (!file1.atEnd()) {
           QByteArray line = file1.readLine();
           animalsList.append(line);
       }

     if (!file2.open(QIODevice::ReadOnly | QIODevice::Text)){
           ui->unfoundList->insertHtml("random problem <br>");
             return;
       }

         while (!file2.atEnd()) {
             QByteArray line = file2.readLine();
             randomList.append(line);
         }

    QList<QString>::iterator i;
    for (i = animalsList.begin(); i != animalsList.end(); ++i){
        if (wordList.contains(*i)){ gamenumber = 2;
        ui->foundList->insertHtml(*i + "was contained <br>");}
    }

    for (i = randomList.begin(); i != randomList.end(); ++i){
        if (wordList.contains(*i)){ gamenumber = 1;
            ui->foundList->insertHtml(*i + "was contained <br>");}
    }
}

void wordsearchgui::onEnterPress(){
    //TODO : Have Bash Script check to see if Inputs are a Word

    int row1, col1, row2, col2;
    row1 = ui->row1spin->value();
    col1 = ui->col1spin->value();
    row2 = ui->row2spin->value();
    col2 = ui->col2spin->value();

    //execute shell script

    ui->row1spin->clear();
    ui->col1spin->clear();
    ui->row2spin->clear();
    ui->col2spin->clear();
    toggle = 0;

    updateList();
}

/*int wordsearchgui::checkFile(){

    QFile file("../animals.dat");
       if (!file.open(QIODevice::ReadOnly | QIODevice::Text)){
           ui->unfoundList->insertHtml("checkfileProblem <br>");
             return;
       }

         while (!file.atEnd()) {
             QByteArray read = file.readLine();
             QString line = QString(read);
             QStringList linetemp = line.split(" ", QString::SkipEmptyParts);
             for(int cc = 0; cc < linetemp.length(); cc++){
                 QTableWidgetItem *newItem = new QTableWidgetItem(linetemp.at(cc));
                 ui->wordSearchDisplay->setItem(rc, cc, newItem);
             }
    }
}*/

void wordsearchgui::generatePress(){

    int rc = 0;

    QString gamename;
    if(gamenumber == 1) gamename = "./random.dat";
    if(gamenumber == 2) gamename = "./animals.dat";



    ui->foundList->insertHtml(QString("%1").arg(gamenumber) + " <br>");

    QFile file(gamename);
       if (!file.open(QIODevice::ReadOnly | QIODevice::Text)){
           ui->unfoundList->insertHtml("gamename problem <br>");
             return;
       }

         while (!file.atEnd()) {
             QByteArray read = file.readLine();
             QString line = QString(read);
             QStringList linetemp = line.split(" ", QString::SkipEmptyParts);
             for(int cc = 0; cc < linetemp.length(); cc++){
                 QTableWidgetItem *newItem = new QTableWidgetItem(linetemp.at(cc));
                 ui->wordSearchDisplay->setItem(rc, cc, newItem);
             }
             rc++;
         }
}

wordsearchgui::~wordsearchgui(){
    delete ui;
}

//LIST OF BSH SCRIPTS NEEDED
/*
  Script that Checks to see if Entry is legit
*/
