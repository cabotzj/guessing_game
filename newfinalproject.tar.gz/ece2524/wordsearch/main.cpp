#include <QtGui/QApplication>
#include "wordsearchgui.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    wordsearchgui w;
    w.show();
    
    return a.exec();
}
